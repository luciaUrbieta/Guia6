
public class Main {
    public static void main(String[] args) {

        //1.
        /*
        Almacenamiento<Integer> almacenamiento = new Almacenamiento();

        almacenamiento.agregarElemento(120);
        almacenamiento.agregarElemento(78);
        almacenamiento.agregarElemento(9);
        almacenamiento.eliminarElemento(9);
        System.out.println(almacenamiento.toString());

        Almacenamiento<String> almacenamiento2 = new Almacenamiento();
        almacenamiento2.agregarElemento("Hola");
        almacenamiento2.agregarElemento("Soy");
        almacenamiento2.agregarElemento("Lucia");
        System.out.println(almacenamiento2.toString());
        */

        //2.
        /*
        Pila<Integer> pila = new Pila<>();

        pila.agregarElemento(126);
        pila.agregarElemento(78);
        pila.agregarElemento(5);
        pila.agregarElemento(8);
        pila.agregarElemento(32);
        System.out.println("Cantidad de elementos: " + pila.cantidadElementos());
        System.out.println(pila.toString());
        pila.quitarElemento();
        pila.quitarElemento();
        System.out.println("Cantidad de elementos: " + pila.cantidadElementos());
        System.out.println(pila.toString());
        */

        //3.
        /*
        OperacionMatematica<Double> operacionMatematica = new OperacionMatematica<>(2.58, 8.9);
        System.out.println(operacionMatematica.suma());
        System.out.println(operacionMatematica.resta());
        System.out.println(operacionMatematica.multiplicacion());
        System.out.println(operacionMatematica.division());
        */

        //4.
        /*
        Conjunto<String> conjunto = new Conjunto<>();
        conjunto.agregarElemento("hola");
        conjunto.agregarElemento("jua");
        conjunto.agregarElemento("jua");
        conjunto.agregarElemento(":)");
        System.out.println(conjunto.estaElemento("hola"));
        System.out.println(conjunto.buscarElemento("jua"));
        */

        //5.
        /*
        ListaOrdenada<Integer> listaOrdenada = new ListaOrdenada<>(false);
        listaOrdenada.agregarElemento(22);
        listaOrdenada.agregarElemento(5);
        listaOrdenada.agregarElemento(97);
        listaOrdenada.agregarElemento(41);
        System.out.println(listaOrdenada.toString());
        */
    }
}